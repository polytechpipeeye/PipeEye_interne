import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist # <-- Publication de Twist
import sys
import termios
import tty
import threading
from rclpy.executors import MultiThreadedExecutor 

# --- Configuration du Contrôle ---
VEL_LINEAR = 0.5  # Vitesse linéaire (m/s) pour 'z' et 's'
VEL_ANGULAR = 0.5 # Vitesse angulaire (rad/s) pour 'q' et 'd'
PUB_RATE_HZ = 20  # Fréquence de publication pour faible latence
# -------------------------------

class TeleopController(Node):
    def __init__(self):
        super().__init__('teleop_controller_node')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10) # <-- Topic: /cmd_vel
        self.current_twist = Twist()
        self.lock = threading.Lock() 
        self.timer = self.create_timer(1.0 / PUB_RATE_HZ, self.publish_twist)
        self.keyboard_thread = threading.Thread(target=self.listen_for_keyboard)
        self.keyboard_thread.daemon = True
        self.keyboard_thread.start()
        self.print_status()

    def get_motion_info(self, key):
        linear = 0.0
        angular = 0.0
        # Logique ZQSD pour les axes X linéaire et Z angulaire
        if key == 'z':
            linear = VEL_LINEAR
        elif key == 's':
            linear = -VEL_LINEAR
        elif key == 'q':
            angular = VEL_ANGULAR
        elif key == 'd':
            angular = -VEL_ANGULAR
        return linear, angular

    def print_status(self):
        print("\n" + "="*50)
        print("Téléopération ROS 2 - Affichage TWIST")
        print("-" * 50)
        print("COMMANDES : [z] Avancer, [s] Reculer, [q] Gauche, [d] Droite, [espace] Stop.")
        with self.lock:
            lin = self.current_twist.linear.x
            ang = self.current_twist.angular.z
            # Affichage demandé
            print(f"ETAT ACTUEL : Linear X: {lin:.2f} m/s | Angular Z: {ang:.2f} rad/s")
        print("="*50 + "\n")

    def publish_twist(self):
        with self.lock:
            self.publisher_.publish(self.current_twist)

    # --- Gestion du Clavier (termios/tty) ---
    def get_key(self, settings):
        fd = sys.stdin.fileno()
        tty.setraw(fd)
        key = sys.stdin.read(1)
        termios.tcsetattr(fd, termios.TCSADRAIN, settings)
        return key

    def listen_for_keyboard(self):
        settings = termios.tcgetattr(sys.stdin.fileno())
        try:
            while rclpy.ok():
                key = self.get_key(settings)
                
                if key in ['z', 's', 'q', 'd', ' ']:
                    linear, angular = (0.0, 0.0) if key == ' ' else self.get_motion_info(key)
                    with self.lock:
                        self.current_twist.linear.x = linear
                        self.current_twist.angular.z = angular
                        self.current_twist.linear.y = 0.0 # Assurer Y et Z restent 0
                    self.print_status()
                
                elif key == '\x03': # Ctrl+C
                    break
        except Exception as e:
            self.get_logger().error(f"Erreur clavier : {e}")
        finally:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, settings)

def main(args=None):
    rclpy.init(args=args)
    node = TeleopController()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin() 
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
